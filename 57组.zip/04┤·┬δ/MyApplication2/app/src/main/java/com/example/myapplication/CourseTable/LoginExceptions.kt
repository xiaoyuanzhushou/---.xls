package com.example.myapplication.CourseTable

class NetworkErrorException(message: String) : Exception(message)

class UserNameErrorException(message: String) : Exception(message)

class PasswordErrorException(message: String) : Exception(message)

class CheckCodeErrorException(message: String) : Exception(message)

class QueuingUpException(message: String) : Exception(message)

class GetTermDataErrorException(message: String) : Exception(message)