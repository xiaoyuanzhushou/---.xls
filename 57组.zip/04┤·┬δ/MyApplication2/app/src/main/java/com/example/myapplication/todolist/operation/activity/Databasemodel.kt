package com.example.myapplication.todolist.operation.activity

object Databasemodel {
    const val MSG_ADD_DATA = 1

    // 删除数据
    const val MSG_DELETE_DATA = 2

    // 修改数据
    const val MSG_UPDATE_DATA = 3

    // 查询数据
    const val MSG_QUERY_DATA = 4
}