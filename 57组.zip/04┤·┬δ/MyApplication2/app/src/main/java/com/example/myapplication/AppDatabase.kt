package com.example.myapplication

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.core.graphics.createBitmap
//
//class AppDatabase(val context: Context,name:String,version:Int):SQLiteOpenHelper(context,name,null,version) {
//
////
////    val creatCourse="create table Course("+"id integer primary key autoincrement,"+
////            "author text,"+"price real"+"")"
//
//
//
//
//
//
//    override fun onCreate(db: SQLiteDatabase?) {
//        db.execSQL(creatCourse)
//    }
//
//    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
//        TODO("Not yet implemented")
//    }
//
//
//}