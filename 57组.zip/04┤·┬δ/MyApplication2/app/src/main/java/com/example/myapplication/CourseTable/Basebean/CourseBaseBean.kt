package com



data class CourseBaseBean(
        var id: Int,
        var courseName: String,
        var color: String,
        var tableId: Int
)