package com.example.physicsexperiment

/**
 * 存储实验5的数据，数据处理公式和数据处理的方法及结果的类
 */
class Database5 {
}