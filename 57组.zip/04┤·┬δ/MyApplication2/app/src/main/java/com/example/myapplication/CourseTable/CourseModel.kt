package com.example.myapplication.CourseTable
data class CourseModel (
    var id:Int,
    var courseName:String,
    var section: Int,
    var sectionSpan:Int,
    var week:Int,
    var classRoom:String,
    var courseFlag:Int
){



}
